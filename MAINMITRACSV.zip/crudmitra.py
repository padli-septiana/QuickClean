import os
import pandas as pd

# Program utama
data_laundry = "laundries.csv"
data_Paket = pd.read_csv("wash_packets.csv") 

def pause():
    os.system("pause")
    
def border(teks):
    print(f'''
=====================
{teks}
=====================''')

def tampilkan_data_laundry(nama_file, nomor_baris=None):
    os.system("cls")
    border("Data Laundry")
    data = pd.read_csv(nama_file)
    
    if nomor_baris is not None:
        baris_tertentu = data.iloc[0:]
        if not baris_tertentu.empty:
            print(baris_tertentu.to_string(index=False))
            print("=======================================\n")
        else:
            print("Tidak Ada Data Laundry")
            print("=======================================\n")
    else:
        print(data.to_string(index=False))
        
    pause()
    main2
    
def edit_data_laundry():
     while True:
        os.system("cls")
        border("Edit Data")

        try:
            # Menggunakan Pandas untuk membaca, mengedit, dan menulis kembali file CSV
            data = pd.read_csv(data_laundry)

            # Menampilkan data sebelumnya
            print(data)

            nomor_baris = int(input("Ingin edit baris keberapa: "))
            
            # Mengecek apakah nomor baris valid
            if nomor_baris < 1 or nomor_baris > len(data):
                print("Nomor baris tidak valid. Silakan masukkan nomor baris yang benar.")
                pause()
                continue
            # Menggunakan loc untuk mengakses baris berdasarkan kondisi
            if not data.loc[data.index == nomor_baris - 1].empty:
                nama_baru = input("Masukkan nama baru (kosongkan untuk menggunakan nilai sebelumnya): ")
                wilayah_baru = input("Masukkan wilayah baru (kosongkan untuk menggunakan nilai sebelumnya): ")
                
                if nama_baru:
                    data.at[nomor_baris - 1, 'nama'] = nama_baru

                if wilayah_baru:
                    data.at[nomor_baris - 1, 'wilayah'] = wilayah_baru

                # Menyimpan DataFrame yang diperbarui kembali ke file CSV
                data.to_csv(data_laundry, index=False)

                print("Data telah berhasil diubah.")
            else:
                print(f"Data pada baris {nomor_baris} tidak ada.")

            pause()
            main2()
        except ValueError:
            print("Nomor baris harus berupa angka. Silakan masukkan nomor baris yang benar.")
            pause()
            continue
        except FileNotFoundError:
            print("File tidak ditemukan.")
            pause()
            continue
        
def hapus_data_laundry():
    while True:
            os.system("cls")
            border("Hapus Data")

            try:
                # Menggunakan Pandas untuk membaca, mengedit, dan menulis kembali file CSV
                data = pd.read_csv(data_laundry)

                # Menampilkan data sebelumnya
                print(data)

                nomor_baris = int(input("Ingin hapus baris keberapa: "))
                
                # Mengecek apakah nomor baris valid
                if nomor_baris < 1 or nomor_baris > len(data):
                    print("Nomor baris tidak valid. Silakan masukkan nomor baris yang benar.")
                    pause()
                    continue
                
                # Menggunakan loc untuk mengakses baris berdasarkan kondisi
                if not data.loc[data.index == nomor_baris - 1].empty:
                    hapusData = data.drop(nomor_baris - 1, axis=0)

                    # Menyimpan DataFrame yang diperbarui kembali ke file CSV
                    hapusData.to_csv(data_laundry, index=False)

                    print("Data telah berhasil dihapus.")
                else:
                    print(f"Data pada baris {nomor_baris} tidak ada.")

                pause()
                main2()
            except ValueError:
                print("Nomor baris harus berupa angka. Silakan masukkan nomor baris yang benar.")
                pause()
                continue
            except FileNotFoundError:
                print("File tidak ditemukan.")
                pause()
                continue

def lihat_paket():
    os.system("cls")
    border("Lihat Paket")
    inputId = int(input("Ingin lihat paket id berapa: "))
    data = data_Paket[data_Paket['id_laundry'] == inputId]
    
    if data.empty:
        print(f"Tidak ada paket dengan ID laundry {inputId}.")
    else:
        print(data)
    
    pause()
    main2()

def tambah_paket():
    while True:
        os.system("cls")
        try:
            # Baca data terakhir dari file CSV
            data_terakhir = pd.read_csv("wash_packets.csv").tail(1)

            # Dapatkan ID terakhir
            id_terakhir = data_terakhir["id"].values[0] if not data_terakhir.empty else 0
            
            # Dapatkan ID_Laundry terakhir
            id_laundryTerdaftar = data_terakhir["id_laundry"].values[0] if not data_terakhir.empty else 0

            # Tambahkan satu ke ID terakhir untuk mendapatkan ID baru
            id_baru = id_terakhir + 1
            
            id_laundry = int(input("Masukkan ID Laundry: "))
            nama_paket = input("Masukkan Nama Paket: ")
            durasi_paket = int(input("Masukkan Durasi Paket: "))
            unit_paket = input("Masukkan Unit Paket: ")
            harga_paket = int(input("Masukkan Harga Paket: "))
            
            if id_laundry < 1 or id_laundry > id_laundryTerdaftar:
                print("ID_Laundry tidak tersedia. Silakan masukkan ID Laundry yang benar.")
                pause()
                continue
            
            else:
                # Buat DataFrame baru dari data baru
                paket_baru = pd.DataFrame({
                    "id": [id_baru],
                    "id_laundry": [id_laundry],
                    "nama": [nama_paket],
                    "durasi": [durasi_paket],
                    "unit": [unit_paket],
                    "harga": [harga_paket]
                })

                # Tambahkan data baru ke DataFrame
                global data_Paket  # Tambahkan ini
                data_Paket = pd.concat([data_Paket, paket_baru], ignore_index=True)

                # Simpan DataFrame yang diperbarui kembali ke file CSV
                data_Paket.to_csv("wash_packets.csv", index=False)
                
                print("Paket baru berhasil ditambahkan.")
        except ValueError:
            print("Masukan tidak valid. Pastikan durasi dan harga berupa angka.")
        
        pause()
        main2()

def edit_paket():
    while True:
        os.system("cls")
        print(data_Paket)
        
        id_paket = int(input("\nMasukkan ID paket yang ingin diubah: "))
        
        if id_paket < 1 or id_paket > len(data_Paket):
            print("Nomor baris tidak valid. Silakan masukkan nomor baris yang benar.\n")
            pause()
            continue
        # Menggunakan loc untuk mengakses baris berdasarkan kondisi
        if not data_Paket.loc[data_Paket.index == id_paket - 1].empty:
            nama_baru = input("\nMasukkan nama baru (kosongkan untuk menggunakan nilai sebelumnya): ")
            harga_baru = input("Masukkan harga baru (kosongkan untuk menggunakan nilai sebelumnya): ")
            unit_baru = input("Masukkan unit baru (kosongkan untuk menggunakan nilai sebelumnya): ")
            
            if nama_baru:
                data_Paket.at[id_paket - 1, 'nama'] = nama_baru

            if harga_baru:
                data_Paket.at[id_paket - 1, 'harga'] = harga_baru
            
            if unit_baru:
                data_Paket.at[id_paket - 1, 'unit'] = unit_baru

            # Menyimpan DataFrame yang diperbarui kembali ke file CSV
            data_Paket.to_csv("wash_packets.csv", index=False)

            print("\nData paket telah berhasil diubah.")
        
        pause()
        main2()

def delete_packet():
    while True:
        os.system("cls")
        print(data_Paket)
        
        id_paket = int(input("\nMasukkan ID paket yang ingin diubah: "))
        
        if id_paket < 1 or id_paket > len(data_Paket):
            print("Nomor baris tidak valid. Silakan masukkan nomor baris yang benar.\n")
            pause()
            continue
        # Menggunakan loc untuk mengakses baris berdasarkan kondisi
        if not data_Paket.loc[data_Paket.index == id_paket - 1].empty:
            hapusData = data_Paket.drop(id_paket - 1, axis=0)

            # Menyimpan DataFrame yang diperbarui kembali ke file CSV
            hapusData.to_csv("wash_packets.csv", index=False)

            print("\nData paket telah berhasil dihapus.")
        
        pause()
        main2()
# ...
def main2():
    while True:
        os.system("cls")
        border("Laundry Aje")
        print("\nMenu:")
        print("===============================")
        print("1. Tampilkan Data Laundry")
        print("2. Edit Data Laundry")
        print("3. Hapus Data Laundry")
        print("4. Lihat Paket Laundry")
        print("5. Tambah Paket")
        print("6. Edit Paket")
        print("7. Hapus Paket")
        print("0. Keluar")
        print('===============================\n')
        pilihan = input("Pilih menu: ")
        if pilihan == '1':
            tampilkan_data_laundry(data_laundry, nomor_baris=2)
        elif pilihan == "2":
            edit_data_laundry()
        elif pilihan == "3":
            hapus_data_laundry()
        elif pilihan == "4":
            lihat_paket()
        elif pilihan == "5": 
            tambah_paket()
        elif pilihan == "6":
            edit_paket()
        elif pilihan == "7":
            delete_packet()
        elif pilihan == '0':
            print("Selesai")
            break
        else:
            print("Pilihan tidak valid. Silakan masukan ulang.")
            pause()
            continue

main2()