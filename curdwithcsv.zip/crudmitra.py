import csv
import pandas as pd 

def file_csv(nama_file):
    data = []
    with open(nama_file, "r", encoding='utf-8-sig') as file:
        readcsv = csv.reader(file)
        for baris in readcsv:
            data.append(baris)
    return data

def write_csv(nama_file, data):
    with open(nama_file, 'w', newline='') as file:
        penulis_csv = csv.writer(file)
        penulis_csv.writerows(data)

def tampilkan_data_laundry(nama_file, nomor_baris=None):
    data = pd.read_csv(nama_file)

    if nomor_baris is not None:
        baris_tertentu = data.iloc[[nomor_baris - 1]]
        if not baris_tertentu.empty:
            print(baris_tertentu.to_string(index=False))
            print("=======================================\n")
        else:
            print("Tidak Ada Data Laundry")
            print("=======================================\n")
    else:
        print(data.to_string(index=False))

def edit_csv(nama_file, baris, nama_baru=None, wilayah_baru=None):
    data = file_csv(nama_file)

    nama_baru = nama_baru if nama_baru is not None else data[baris][1]
    wilayah_baru = wilayah_baru if wilayah_baru is not None else data[baris][2]

    data[baris][1] = nama_baru
    data[baris][2] = wilayah_baru

    write_csv(nama_file, data)

def edit_data_laundry():
    nomor_baris = 2  
    tampilkan_data_laundry(data_laundry, nomor_baris)
    
    baris_yang_diubah = nomor_baris 

    nama_baru = input("Masukkan nama baru (kosongkan untuk menggunakan nilai sebelumnya): ")
    wilayah_baru = input("Masukkan wilayah baru (kosongkan untuk menggunakan nilai sebelumnya): ")

    edit_csv(data_laundry, baris_yang_diubah, nama_baru, wilayah_baru)
    print("Data telah berhasil diubah.")

def hapus_data_laundry(nama_file):
    data = file_csv(nama_file)

    if len(data) >= 2:
        del data[1] 
        write_csv(nama_file, data)
        print("Data pada baris ke-2 berhasil dihapus!")
    else:
        print("Hapus Data Dibatalkan!")

def lihat_paket():
    csvFile = pd.read_csv("wash_packets.csv")
    print(csvFile)

def tambah_paket():
    try:
        id_laundry = input("Masukkan ID Laundry: ")
        nama_paket = input("Masukkan Nama Paket: ")
        durasi_paket = int(input("Masukkan Durasi Paket: "))
        unit_paket = input("Masukkan Unit Paket: ")
        harga_paket = int(input("Masukkan Harga Paket: "))

        paket_baru = {
            "id": None, 
            "id_laundry": id_laundry,
            "nama": nama_paket,
            "durasi": durasi_paket,
            "unit": unit_paket,
            "harga": harga_paket
        }

        paketLama = pd.read_csv("wash_packets.csv")
        new_packet_df = pd.DataFrame([paket_baru])
        updated_paket = paketLama.append(new_packet_df, ignore_index=True)
        updated_paket.to_csv("wash_packets.csv", index=False)

        print("Paket baru berhasil ditambahkan.")
    except ValueError:
        print("Masukan tidak valid. Pastikan durasi dan harga berupa angka.")

def edit_paket():
    lihat_paket()
    
    id_paket = input("Masukkan ID paket yang ingin diubah: ")
    
    nama_baru = input("Masukkan nama baru (kosongkan untuk menggunakan nilai sebelumnya): ")
    harga_baru = input("Masukkan harga baru (kosongkan untuk menggunakan nilai sebelumnya): ")
    unit_baru = input("Masukkan unit baru (kosongkan untuk menggunakan nilai sebelumnya): ")
    
    paket_data = file_csv("wash_packets.csv")
    
    for i in range(1, len(paket_data)):
        if paket_data[i][0] == id_paket:
            paket_data[i][2] = nama_baru if nama_baru else paket_data[i][2]
            paket_data[i][5] = harga_baru if harga_baru else paket_data[i][5]
            paket_data[i][4] = unit_baru if unit_baru else paket_data[i][4]
            break
    
    write_csv("wash_packets.csv", paket_data)
    print("Data paket telah berhasil diubah.")

def delete_packet(id_wash_packet=2):
    pd.DataFrame(columns=["id", "id_laundry", "nama", "durasi", "unit", "harga"]).to_csv("wash_packets.csv", index=False)
    print("Semua paket berhasil dihapus.")


# Program utama
data_laundry = "laundries.csv"

# ...

while True:
    print("\nMenu:")
    print("===============================")
    print("1. Tampilkan Data Laundry")
    print("0. Keluar")
    print('===============================\n')

    pilihan = input("Pilih menu (1/0): ")
    if pilihan == '1':
        tampilkan_data_laundry(data_laundry, nomor_baris=2)
        print("1. Edit Data Laundry")
        print("2. Hapus Data Laundry")
        print("3. Lihat Paket Laundry")
        print("4. Tambah Paket")
        print("5. Edit Paket")
        print("6. Hapus Paket")
        pilihan_satu = input("Pilih Menu 1-5: ")
        if pilihan_satu == "1":
            edit_data_laundry()
        elif pilihan_satu == "2":
            hapus_data_laundry(data_laundry)
        elif pilihan_satu == "3":
            lihat_paket()
        elif pilihan_satu == "4": 
            tambah_paket()
        elif pilihan_satu == "5":
            edit_paket()
        elif pilihan_satu == "6":
            delete_packet()
        elif pilihan_satu == '0':
            print("Selesai")
    else:
        print("Pilihan tidak valid. Silakan pilih menu (1-0).")


